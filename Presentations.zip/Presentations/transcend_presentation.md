# Transcend Consent Management Implementation Plan
## Digital Solutions Managed Sites

---

## Executive Summary

**67 Total Sites** across 5 instances

| Priority | Sites | Risk Level |
|----------|-------|------------|
| Phase 1 | 6 | HIGH - Member PHI/PII |
| Phase 2 | 27 | HIGH - Provider Access |
| Phase 3 | 7 | MEDIUM - B2B Data |
| Phase 4 | 24 | LOW - Marketing |
| Phase 5 | 3 | LOW - Internal |

---

## Instance 1: Member Portals (6 sites)
### HIGHEST PRIORITY - PHI/PII Data

**Sites:**
- vsp.com
- mymetlifevision.com
- healthyeyes.vsp.com/anthem
- healthyeyes.mymetlifevision.com
- companyname.vspforme.com
- openenrollment.vsp.com

**Requirements:** HIPAA compliance, strictest consent defaults

---

## Instance 2: Provider Portals (27 sites)
### HIGH PRIORITY - Patient Data Access

**Key Sites:**
- doctor.vsp.com
- vspproviderhub.com
- eyefinity.com
- vspprm.com
- vsplrm.com

**Plus 22 additional provider sites**

**Requirements:** HIPAA, B2B privacy, professional access controls

---

## Instance 3: Broker & Client (7 sites)
### MEDIUM PRIORITY - Business Data

**Sites:**
- visionplans.vsp.com
- visionbenefits.vsp.com
- vspcoveredcaagent.com
- brokers.vsphub.com
- employers.vsphub.com
- individualplanpartner.com
- visionpartners.vsp.com

**Requirements:** B2B privacy, SOC 2 considerations

---

## Instance 4: Consumer Marketing (24 sites)
### STANDARD PRIORITY - Marketing Data

**Categories:**
- VSP Marketing (12 sites)
- Eyewear Brands (9 sites)
- Optics (3 sites)

**Examples:** findvsp.com, marchon.com, flexon.com, vspoffers.com

**Requirements:** Standard CCPA/GDPR compliance

---

## Instance 5: Corporate & Internal (3 sites)
### LOW PRIORITY - Internal/Public

**Sites:**
- vspvision.com
- vspglobalresources.com
- internal.vspprm.com

**Requirements:** Employee privacy, public information

---

## Current Status

### Implementation Progress
- ✅ Complete: 15 sites (22%)
- ⏳ In Progress: 1 site (1%)
- 🚀 Not Started: 8 sites (12%)
- ❓ Not Specified: 32 sites (48%)
- ❌ Not Needed: 11 sites (16%)

---

## Implementation Timeline

### Q1 2025
- **Instance 1**: All 6 member sites
- **Instance 2**: Begin provider sites (10-15 sites)

### Q2 2025
- **Instance 2**: Complete provider sites
- **Instance 3**: All broker/client sites

### Q3 2025
- **Instance 4**: Consumer marketing sites
- **Instance 5**: Corporate/internal sites

---

## Key Decisions Needed

1. **Verify subpages vs domains**
   - 7 entries appear to be forms/subpages
   
2. **Clarify multiple domains**
   - Entry with 4 VSP care variants
   
3. **Assess unspecified sites**
   - 32 sites need Transcend status review
   
4. **Validate "Not Needed" sites**
   - Confirm 11 sites are truly out of scope

---

## Budget Considerations

### Instance Costs
- 5 separate Transcend instances
- Cross-domain sync within instances
- No sync between instances (data isolation)

### Potential Savings
- Review "Not Needed" sites
- Consolidate subpages under parent domains
- Consider merging low-risk instances

---

## Next Steps

1. **Immediate**: Start Instance 1 (Member Portals)
2. **Week 1**: Assess 32 unspecified sites
3. **Week 2**: Clarify subpage/domain questions
4. **Week 3**: Finalize implementation roadmap
5. **Week 4**: Begin Instance 2 planning